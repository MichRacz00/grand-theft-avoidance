(function(window, undefined) {
  var dictionary = {
    "f72c652b-60de-4114-bfaf-5451b9bca421": "Manage Stores",
    "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a": "Devision Manager",
    "a1664eae-80b8-446f-88cd-4a2c5594ffcc": "Store Statistics",
    "d12245cc-1680-458d-89dd-4f0d7fb22724": "Login",
    "d069f680-ad13-4e84-ab62-832d02e93399": "Manage Accounts",
    "f39803f7-df02-4169-93eb-7547fb8c961a": "Template 1",
    "bb8abf58-f55e-472d-af05-a7d1bb0cc014": "default"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);