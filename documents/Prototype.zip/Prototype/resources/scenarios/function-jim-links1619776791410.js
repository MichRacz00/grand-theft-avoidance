(function(window, undefined) {

  var jimLinks = {
    "f72c652b-60de-4114-bfaf-5451b9bca421" : {
      "Rectangle_3" : [
        "d069f680-ad13-4e84-ab62-832d02e93399"
      ],
      "Rectangle_6" : [
        "d069f680-ad13-4e84-ab62-832d02e93399"
      ],
      "Paragraph_6" : [
        "a1664eae-80b8-446f-88cd-4a2c5594ffcc"
      ],
      "Paragraph_8" : [
        "d069f680-ad13-4e84-ab62-832d02e93399"
      ],
      "Rectangle_9" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Paragraph_10" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a" : {
      "Paragraph_6" : [
        "a1664eae-80b8-446f-88cd-4a2c5594ffcc"
      ],
      "Rectangle_6" : [
        "d069f680-ad13-4e84-ab62-832d02e93399"
      ],
      "Rectangle_2" : [
        "f72c652b-60de-4114-bfaf-5451b9bca421"
      ],
      "Rectangle_3" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "a1664eae-80b8-446f-88cd-4a2c5594ffcc" : {
      "Paragraph_10" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Paragraph_12" : [
        "d069f680-ad13-4e84-ab62-832d02e93399"
      ],
      "Paragraph_13" : [
        "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Button_1" : [
        "a1664eae-80b8-446f-88cd-4a2c5594ffcc"
      ]
    },
    "d069f680-ad13-4e84-ab62-832d02e93399" : {
      "Rectangle_3" : [
        "f72c652b-60de-4114-bfaf-5451b9bca421"
      ],
      "Rectangle_6" : [
        "d069f680-ad13-4e84-ab62-832d02e93399"
      ],
      "Paragraph_9" : [
        "a1664eae-80b8-446f-88cd-4a2c5594ffcc"
      ],
      "Paragraph_11" : [
        "d069f680-ad13-4e84-ab62-832d02e93399"
      ],
      "Rectangle_5" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Paragraph_13" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);