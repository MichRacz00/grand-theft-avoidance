function initData() {
  jimData.datamasters["test"] = [
    {
      "id": 1,
      "datamaster": "test",
      "userdata": {
        "769e06e9-1514-4de2-8f20-49c87a11fe30": "sample text",
        "d63826e9-38de-4d74-8029-b5f17b5b3e47": "sample text",
        "37187448-434f-474b-a2bb-dec15bf436a3": "sample text"
      }
    },
    {
      "id": 2,
      "datamaster": "test",
      "userdata": {
        "769e06e9-1514-4de2-8f20-49c87a11fe30": "sample text",
        "d63826e9-38de-4d74-8029-b5f17b5b3e47": "sample text",
        "37187448-434f-474b-a2bb-dec15bf436a3": "sample text"
      }
    },
    {
      "id": 3,
      "datamaster": "test",
      "userdata": {
        "769e06e9-1514-4de2-8f20-49c87a11fe30": "sample text",
        "d63826e9-38de-4d74-8029-b5f17b5b3e47": "sample text",
        "37187448-434f-474b-a2bb-dec15bf436a3": "sample text"
      }
    }
  ];

  jimData.isInitialized = true;
}