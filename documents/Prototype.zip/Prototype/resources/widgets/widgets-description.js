	window.widgets = {
		descriptionMap : widgetDescriptionMap = {},
		rootWidgetMap : widgetRootMap = {}
	};

	widgets.descriptionMap[["s-Input_search", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-Input_search", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Search field", "s-Search-input"]; 

	widgets.descriptionMap[["s-Image_37", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-Image_37", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Zoom icon", "s-Image_37"]; 

	widgets.descriptionMap[["s-Rectangle_1", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Rectangle", "s-Rectangle_1"]; 

	widgets.descriptionMap[["s-Paragraph_1", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Rectangle_3", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Rectangle", "s-Rectangle_3"]; 

	widgets.descriptionMap[["s-Rectangle_4", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Rectangle", "s-Rectangle_4"]; 

	widgets.descriptionMap[["s-9e4c7f27", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-9e4c7f27", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Text_cell_17", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_17", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-b98c37cc", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-b98c37cc", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Text_cell_18", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_18", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-821da833", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-821da833", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Text_cell_19", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_19", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-8aa84e0f", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-8aa84e0f", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Text_cell_20", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_20", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-8597c32d", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-8597c32d", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Text_cell_21", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_21", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-3b904a05", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-3b904a05", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Text_cell_22", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_22", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-c9df02ae", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-c9df02ae", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Text_cell_23", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_23", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-59cfd010", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-59cfd010", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Text_cell_24", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_24", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-1a3c2cda", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-1a3c2cda", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Text_cell_25", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_25", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-be36f5df", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-be36f5df", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Text_cell_26", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_26", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-4d7fbcfe", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-4d7fbcfe", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Text_cell_27", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_27", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-dce27199", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-dce27199", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Text_cell_28", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_28", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-7c96b65d", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-7c96b65d", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Text_cell_29", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_29", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-353f68b4", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-353f68b4", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Text_cell_30", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_30", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-68a493a8", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-68a493a8", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Text_cell_31", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_31", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-7a679953", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-7a679953", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Text_cell_32", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_32", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Button_1", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Button_2", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-Button_2", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Button", "s-Button_2"]; 

	widgets.descriptionMap[["s-Button_3", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-Button_3", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Button", "s-Button_3"]; 

	widgets.descriptionMap[["s-Button_4", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-Button_4", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Button", "s-Button_4"]; 

	widgets.descriptionMap[["s-Button_5", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-Button_5", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Button", "s-Button_5"]; 

	widgets.descriptionMap[["s-Button_6", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-Button_6", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Button", "s-Button_6"]; 

	widgets.descriptionMap[["s-Rectangle_2", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Rectangle", "s-Rectangle_2"]; 

	widgets.descriptionMap[["s-Rectangle_5", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_5", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Rectangle", "s-Rectangle_5"]; 

	widgets.descriptionMap[["s-Rectangle_6", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_6", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Rectangle", "s-Rectangle_6"]; 

	widgets.descriptionMap[["s-Rectangle_7", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_7", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Rectangle", "s-Rectangle_7"]; 

	widgets.descriptionMap[["s-Rectangle_8", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_8", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Rectangle", "s-Rectangle_8"]; 

	widgets.descriptionMap[["s-Image_2", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Image", "s-Image_2"]; 

	widgets.descriptionMap[["s-Paragraph_6", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_6", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Text", "s-Paragraph_6"]; 

	widgets.descriptionMap[["s-Paragraph_7", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_7", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Text", "s-Paragraph_7"]; 

	widgets.descriptionMap[["s-Paragraph_8", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_8", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Text", "s-Paragraph_8"]; 

	widgets.descriptionMap[["s-Paragraph_9", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_9", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Text", "s-Paragraph_9"]; 

	widgets.descriptionMap[["s-Rectangle_9", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_9", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Rectangle", "s-Rectangle_9"]; 

	widgets.descriptionMap[["s-Paragraph_10", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_10", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Text", "s-Paragraph_10"]; 

	widgets.descriptionMap[["s-Image_22", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-Image_22", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Burger menu", "s-Image_22"]; 

	widgets.descriptionMap[["s-Paragraph_5", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "f72c652b-60de-4114-bfaf-5451b9bca421"]] = ["Text", "s-Paragraph_5"]; 

	widgets.descriptionMap[["s-Image_2", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ["Image", "s-Image_2"]; 

	widgets.descriptionMap[["s-Rectangle_8", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_8", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ["Rectangle", "s-Rectangle_8"]; 

	widgets.descriptionMap[["s-Paragraph_6", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_6", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ["Text", "s-Paragraph_6"]; 

	widgets.descriptionMap[["s-Rectangle_7", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_7", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ["Rectangle", "s-Rectangle_7"]; 

	widgets.descriptionMap[["s-Paragraph_7", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_7", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ["Text", "s-Paragraph_7"]; 

	widgets.descriptionMap[["s-Rectangle_6", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_6", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ["Rectangle", "s-Rectangle_6"]; 

	widgets.descriptionMap[["s-Paragraph_8", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_8", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ["Text", "s-Paragraph_8"]; 

	widgets.descriptionMap[["s-Paragraph_9", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_9", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ["Text", "s-Paragraph_9"]; 

	widgets.descriptionMap[["s-Rectangle_2", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ["Rectangle", "s-Rectangle_2"]; 

	widgets.descriptionMap[["s-Rectangle_3", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ["Rectangle", "s-Rectangle_3"]; 

	widgets.descriptionMap[["s-Paragraph_10", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_10", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ["Text", "s-Paragraph_10"]; 

	widgets.descriptionMap[["s-Image_22", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ""; 

			widgets.rootWidgetMap[["s-Image_22", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ["Burger menu", "s-Image_22"]; 

	widgets.descriptionMap[["s-Input_search", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ""; 

			widgets.rootWidgetMap[["s-Input_search", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ["Search field", "s-Search-input"]; 

	widgets.descriptionMap[["s-Image_37", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ""; 

			widgets.rootWidgetMap[["s-Image_37", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ["Zoom icon", "s-Image_37"]; 

	widgets.descriptionMap[["s-Paragraph_1", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Paragraph_3", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ["Text", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Paragraph_4", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ["Text", "s-Paragraph_4"]; 

	widgets.descriptionMap[["s-Paragraph_14", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_14", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ["Text", "s-Paragraph_14"]; 

	widgets.descriptionMap[["s-Paragraph_15", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_15", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ["Text", "s-Paragraph_15"]; 

	widgets.descriptionMap[["s-Rectangle_5", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_5", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ["Rectangle", "s-Rectangle_5"]; 

	widgets.descriptionMap[["s-Paragraph_11", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_11", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ["Text", "s-Paragraph_11"]; 

	widgets.descriptionMap[["s-Paragraph_5", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ["Text", "s-Paragraph_5"]; 

	widgets.descriptionMap[["s-Rectangle_1", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ["Rectangle", "s-Rectangle_1"]; 

	widgets.descriptionMap[["s-Paragraph_12", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_12", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ["Text", "s-Paragraph_12"]; 

	widgets.descriptionMap[["s-Paragraph_13", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_13", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ["Text", "s-Paragraph_13"]; 

	widgets.descriptionMap[["s-Rectangle_4", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ["Rectangle", "s-Rectangle_4"]; 

	widgets.descriptionMap[["s-Panel_1", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_1", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ["Dynamic Panel", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Image_4", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ""; 

			widgets.rootWidgetMap[["s-Image_4", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ["Dynamic Panel", "s-Dynamic_Panel_2"]; 

	widgets.descriptionMap[["s-Paragraph_16", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_16", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ["Text", "s-Paragraph_16"]; 

	widgets.descriptionMap[["s-Paragraph_2", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ["Text", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Panel_2", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_2", "b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a"]] = ["Dynamic Panel", "s-Dynamic_Panel_2"]; 

	widgets.descriptionMap[["s-Rectangle_2", "a1664eae-80b8-446f-88cd-4a2c5594ffcc"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "a1664eae-80b8-446f-88cd-4a2c5594ffcc"]] = ["Rectangle", "s-Rectangle_2"]; 

	widgets.descriptionMap[["s-Rectangle_6", "a1664eae-80b8-446f-88cd-4a2c5594ffcc"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_6", "a1664eae-80b8-446f-88cd-4a2c5594ffcc"]] = ["Rectangle", "s-Rectangle_6"]; 

	widgets.descriptionMap[["s-Rectangle_7", "a1664eae-80b8-446f-88cd-4a2c5594ffcc"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_7", "a1664eae-80b8-446f-88cd-4a2c5594ffcc"]] = ["Rectangle", "s-Rectangle_7"]; 

	widgets.descriptionMap[["s-Rectangle_8", "a1664eae-80b8-446f-88cd-4a2c5594ffcc"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_8", "a1664eae-80b8-446f-88cd-4a2c5594ffcc"]] = ["Rectangle", "s-Rectangle_8"]; 

	widgets.descriptionMap[["s-Paragraph_7", "a1664eae-80b8-446f-88cd-4a2c5594ffcc"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_7", "a1664eae-80b8-446f-88cd-4a2c5594ffcc"]] = ["Text", "s-Paragraph_7"]; 

	widgets.descriptionMap[["s-Paragraph_8", "a1664eae-80b8-446f-88cd-4a2c5594ffcc"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_8", "a1664eae-80b8-446f-88cd-4a2c5594ffcc"]] = ["Text", "s-Paragraph_8"]; 

	widgets.descriptionMap[["s-Paragraph_9", "a1664eae-80b8-446f-88cd-4a2c5594ffcc"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_9", "a1664eae-80b8-446f-88cd-4a2c5594ffcc"]] = ["Text", "s-Paragraph_9"]; 

	widgets.descriptionMap[["s-Rectangle_9", "a1664eae-80b8-446f-88cd-4a2c5594ffcc"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_9", "a1664eae-80b8-446f-88cd-4a2c5594ffcc"]] = ["Rectangle", "s-Rectangle_9"]; 

	widgets.descriptionMap[["s-Paragraph_10", "a1664eae-80b8-446f-88cd-4a2c5594ffcc"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_10", "a1664eae-80b8-446f-88cd-4a2c5594ffcc"]] = ["Text", "s-Paragraph_10"]; 

	widgets.descriptionMap[["s-Paragraph_11", "a1664eae-80b8-446f-88cd-4a2c5594ffcc"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_11", "a1664eae-80b8-446f-88cd-4a2c5594ffcc"]] = ["Text", "s-Paragraph_11"]; 

	widgets.descriptionMap[["s-Rectangle_10", "a1664eae-80b8-446f-88cd-4a2c5594ffcc"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_10", "a1664eae-80b8-446f-88cd-4a2c5594ffcc"]] = ["Rectangle", "s-Rectangle_10"]; 

	widgets.descriptionMap[["s-Rectangle_11", "a1664eae-80b8-446f-88cd-4a2c5594ffcc"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_11", "a1664eae-80b8-446f-88cd-4a2c5594ffcc"]] = ["Rectangle", "s-Rectangle_11"]; 

	widgets.descriptionMap[["s-Image_2", "a1664eae-80b8-446f-88cd-4a2c5594ffcc"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "a1664eae-80b8-446f-88cd-4a2c5594ffcc"]] = ["Dynamic Panel", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Paragraph_5", "a1664eae-80b8-446f-88cd-4a2c5594ffcc"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "a1664eae-80b8-446f-88cd-4a2c5594ffcc"]] = ["Text", "s-Paragraph_5"]; 

	widgets.descriptionMap[["s-Panel_1", "a1664eae-80b8-446f-88cd-4a2c5594ffcc"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_1", "a1664eae-80b8-446f-88cd-4a2c5594ffcc"]] = ["Dynamic Panel", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Paragraph_1", "a1664eae-80b8-446f-88cd-4a2c5594ffcc"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "a1664eae-80b8-446f-88cd-4a2c5594ffcc"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Paragraph_2", "a1664eae-80b8-446f-88cd-4a2c5594ffcc"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "a1664eae-80b8-446f-88cd-4a2c5594ffcc"]] = ["Text", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Image_35", "a1664eae-80b8-446f-88cd-4a2c5594ffcc"]] = ""; 

			widgets.rootWidgetMap[["s-Image_35", "a1664eae-80b8-446f-88cd-4a2c5594ffcc"]] = ["User icon", "s-Image_35"]; 

	widgets.descriptionMap[["s-Text_1", "a1664eae-80b8-446f-88cd-4a2c5594ffcc"]] = ""; 

			widgets.rootWidgetMap[["s-Text_1", "a1664eae-80b8-446f-88cd-4a2c5594ffcc"]] = ["Text", "s-Text_1"]; 

	widgets.descriptionMap[["s-Rectangle_3", "a1664eae-80b8-446f-88cd-4a2c5594ffcc"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "a1664eae-80b8-446f-88cd-4a2c5594ffcc"]] = ["Percentage indicator", "s-Porcentage-indicator"]; 

	widgets.descriptionMap[["s-Rectangle_4", "a1664eae-80b8-446f-88cd-4a2c5594ffcc"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "a1664eae-80b8-446f-88cd-4a2c5594ffcc"]] = ["Percentage indicator", "s-Porcentage-indicator"]; 

	widgets.descriptionMap[["s-Rectangle_5", "a1664eae-80b8-446f-88cd-4a2c5594ffcc"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_5", "a1664eae-80b8-446f-88cd-4a2c5594ffcc"]] = ["Percentage indicator", "s-Porcentage-indicator"]; 

	widgets.descriptionMap[["s-Paragraph_12", "a1664eae-80b8-446f-88cd-4a2c5594ffcc"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_12", "a1664eae-80b8-446f-88cd-4a2c5594ffcc"]] = ["Text", "s-Paragraph_12"]; 

	widgets.descriptionMap[["s-Paragraph_13", "a1664eae-80b8-446f-88cd-4a2c5594ffcc"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_13", "a1664eae-80b8-446f-88cd-4a2c5594ffcc"]] = ["Text", "s-Paragraph_13"]; 

	widgets.descriptionMap[["s-Input_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Input_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Input Text Field", "s-Input_1"]; 

	widgets.descriptionMap[["s-Input_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Input_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Input Text Field", "s-Input_2"]; 

	widgets.descriptionMap[["s-Paragraph_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Input_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Input_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Check Box", "s-Input_3"]; 

	widgets.descriptionMap[["s-Paragraph_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Text", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Button_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Paragraph_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Text", "s-Paragraph_4"]; 

	widgets.descriptionMap[["s-Image_5", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Image_5", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Right arrow", "s-Image_5"]; 

	widgets.descriptionMap[["s-Paragraph_5", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Text", "s-Paragraph_5"]; 

	widgets.descriptionMap[["s-Paragraph_2", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ["h1", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Button_1", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ["Button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Cell_13", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_13", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_14", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_14", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_15", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_15", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_16", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_16", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_17", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_17", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_18", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_18", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_19", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_19", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_20", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_20", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_21", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_21", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_22", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_22", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_23", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_23", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Cell_24", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_24", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ["Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Paragraph_1", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Paragraph_3", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ["Text", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Paragraph_4", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ["Text", "s-Paragraph_4"]; 

	widgets.descriptionMap[["s-Button_2", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ""; 

			widgets.rootWidgetMap[["s-Button_2", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ["Button", "s-Button_2"]; 

	widgets.descriptionMap[["s-Button_3", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ""; 

			widgets.rootWidgetMap[["s-Button_3", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ["Button", "s-Button_3"]; 

	widgets.descriptionMap[["s-Button_4", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ""; 

			widgets.rootWidgetMap[["s-Button_4", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ["Button", "s-Button_4"]; 

	widgets.descriptionMap[["s-Button_5", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ""; 

			widgets.rootWidgetMap[["s-Button_5", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ["Button", "s-Button_5"]; 

	widgets.descriptionMap[["s-Paragraph_5", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ["Text", "s-Paragraph_5"]; 

	widgets.descriptionMap[["s-Paragraph_6", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_6", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ["Text", "s-Paragraph_6"]; 

	widgets.descriptionMap[["s-Paragraph_7", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_7", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ["Text", "s-Paragraph_7"]; 

	widgets.descriptionMap[["s-Paragraph_8", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_8", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ["Text", "s-Paragraph_8"]; 

	widgets.descriptionMap[["s-Category_2", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ""; 

			widgets.rootWidgetMap[["s-Category_2", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ["Custom Select List", "s-Category_2"]; 

	widgets.descriptionMap[["s-Rectangle_3", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ["Rectangle", "s-Rectangle_3"]; 

	widgets.descriptionMap[["s-Rectangle_4", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ["Rectangle", "s-Rectangle_4"]; 

	widgets.descriptionMap[["s-Rectangle_2", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ["Rectangle", "s-Rectangle_2"]; 

	widgets.descriptionMap[["s-Rectangle_6", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_6", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ["Rectangle", "s-Rectangle_6"]; 

	widgets.descriptionMap[["s-Rectangle_7", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_7", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ["Rectangle", "s-Rectangle_7"]; 

	widgets.descriptionMap[["s-Rectangle_8", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_8", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ["Rectangle", "s-Rectangle_8"]; 

	widgets.descriptionMap[["s-Image_2", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ["Image", "s-Image_2"]; 

	widgets.descriptionMap[["s-Paragraph_9", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_9", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ["Text", "s-Paragraph_9"]; 

	widgets.descriptionMap[["s-Paragraph_10", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_10", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ["Text", "s-Paragraph_10"]; 

	widgets.descriptionMap[["s-Paragraph_11", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_11", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ["Text", "s-Paragraph_11"]; 

	widgets.descriptionMap[["s-Paragraph_12", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_12", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ["Text", "s-Paragraph_12"]; 

	widgets.descriptionMap[["s-Rectangle_5", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_5", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ["Rectangle", "s-Rectangle_5"]; 

	widgets.descriptionMap[["s-Paragraph_13", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_13", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ["Text", "s-Paragraph_13"]; 

	widgets.descriptionMap[["s-Image_22", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ""; 

			widgets.rootWidgetMap[["s-Image_22", "d069f680-ad13-4e84-ab62-832d02e93399"]] = ["Burger menu", "s-Image_22"]; 

	