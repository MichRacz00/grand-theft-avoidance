var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1280" deviceHeight="800">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1619776791410.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1619776791410-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Devision Manager" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a-1619776791410.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a-1619776791410-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/b2fc70f6-5a7c-4763-a98c-cfa4c56e3e4a-1619776791410-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Dynamic_Panel_4" class="pie dynamicpanel firer commentable non-processed" customid="Dynamic Panel 2" datasizewidth="270.0px" datasizeheight="800.0px" dataX="-270.0" dataY="-0.0" >\
        <div id="s-Panel_4" class="pie panel default firer click commentable non-processed" customid="Panel 2"  datasizewidth="270.0px" datasizeheight="800.0px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="layoutWrapper scrollable">\
          	  <div class="paddingLayer">\
                <div class="freeLayout">\
                <div id="s-Image_2" class="pie image firer ie-background commentable non-processed" customid="Image"   datasizewidth="127.0px" datasizeheight="125.0px" dataX="71.5" dataY="86.0"   alt="image">\
                  <div class="borderLayer">\
                  	<div class="imageViewport">\
                  		<img src="resources/jim/images/common/cross.svg" />\
                  	</div>\
                  </div>\
                </div>\
\
\
                <div id="s-Group_11" class="group firer ie-background commentable non-processed" customid="Dashboard" datasizewidth="0.0px" datasizeheight="0.0px" >\
                  <div id="s-Rectangle_8" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle"   datasizewidth="270.0px" datasizeheight="87.4px" datasizewidthpx="269.9999999999999" datasizeheightpx="87.41666666666663" dataX="0.0" dataY="258.0" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Rectangle_8_0"></span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Paragraph_6" class="pie richtext autofit firer click ie-background commentable non-processed" customid="Paragraph"   datasizewidth="156.5px" datasizeheight="36.0px" dataX="14.5" dataY="283.7" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Paragraph_6_0">Dashboard</span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
\
\
                <div id="s-Group_10" class="group firer ie-background commentable non-processed" customid="Time-Theft" datasizewidth="0.0px" datasizeheight="0.0px" >\
                  <div id="s-Rectangle_7" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle"   datasizewidth="270.0px" datasizeheight="87.4px" datasizewidthpx="269.9999999999999" datasizeheightpx="87.41666666666674" dataX="0.0" dataY="345.4" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Rectangle_7_0"></span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Paragraph_7" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="161.8px" datasizeheight="36.0px" dataX="10.0" dataY="370.0" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Paragraph_7_0">Time - theft</span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
\
\
                <div id="s-Group_9" class="group firer ie-background commentable non-processed" customid="Manage Accounts" datasizewidth="0.0px" datasizeheight="0.0px" >\
                  <div id="s-Rectangle_6" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle"   datasizewidth="270.0px" datasizeheight="87.4px" datasizewidthpx="269.9999999999999" datasizeheightpx="87.41666666666674" dataX="0.0" dataY="432.8" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Rectangle_6_0"></span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Paragraph_8" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="256.2px" datasizeheight="36.0px" dataX="10.0" dataY="460.0" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Paragraph_8_0">Manage Accounts</span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
\
\
                <div id="s-Group_8" class="group firer ie-background commentable non-processed" customid="Manage Stores" datasizewidth="0.0px" datasizeheight="0.0px" >\
                  <div id="s-Paragraph_9" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="217.0px" datasizeheight="36.0px" dataX="10.0" dataY="545.0" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Paragraph_9_0">Manage Stores</span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Rectangle_2" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle"   datasizewidth="270.0px" datasizeheight="87.4px" datasizewidthpx="270.0000000000003" datasizeheightpx="87.41666666666652" dataX="0.0" dataY="520.2" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Rectangle_2_0"></span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
\
\
                <div id="s-Group_7" class="group firer ie-background commentable non-processed" customid="Logout" datasizewidth="0.0px" datasizeheight="0.0px" >\
                  <div id="s-Rectangle_3" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle"   datasizewidth="270.0px" datasizeheight="87.4px" datasizewidthpx="270.0000000000003" datasizeheightpx="87.41666666666652" dataX="0.0" dataY="607.7" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Rectangle_3_0"></span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Paragraph_10" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="97.9px" datasizeheight="36.0px" dataX="10.0" dataY="633.4" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Paragraph_10_0">Logout</span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
\
                </div>\
\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_22" class="pie image firer click ie-background commentable non-processed" customid="Burger"   datasizewidth="39.0px" datasizeheight="23.0px" dataX="31.0" dataY="22.0"   alt="image" systemName="./images/48c31f1d-456f-4733-b6be-2bc46cb082fc.svg" overlay="#434343">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="18px" version="1.1" viewBox="0 0 25 18" width="25px">\
          	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
          	    <title>Menu Burger Icon</title>\
          	    <desc>Created with Sketch.</desc>\
          	    <defs />\
          	    <g fill="none" fill-rule="evenodd" id="s-Image_22-Page-1" stroke="none" stroke-width="1">\
          	        <g fill="#333333" id="Header-#2" transform="translate(-120.000000, -26.000000)">\
          	            <g id="s-Image_22-Top">\
          	                <path d="M145,26 L145,28 L120,28 L120,26 L145,26 Z M145,42 L145,44 L120,44 L120,42 L145,42 Z M145,34 L145,36 L120,36 L120,34 L145,34 Z" id="s-Image_22-Menu-Burger-Icon" style="fill:#434343 !important;" />\
          	            </g>\
          	        </g>\
          	    </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_1" class="pie image lockV firer ie-background commentable non-processed" customid="Map"   datasizewidth="662.0px" datasizeheight="499.2px" dataX="578.0" dataY="199.0" aspectRatio="0.7540603"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/4825f14c-9bfe-4aa3-aa3e-d633254668f5.PNG" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_6" class="group firer ie-background commentable non-processed" customid="Group 6" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Search-input" class="group firer ie-background commentable non-processed" customid="Search-input" datasizewidth="347.0px" datasizeheight="46.0px" >\
          <div id="s-Input_search" class="pie text firer commentable non-processed" customid="Input_search"  datasizewidth="347.0px" datasizeheight="46.0px" dataX="107.0" dataY="315.0" ><div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Address"/></div></div>  </div></div></div>\
\
          <div id="s-Image_37" class="pie image firer ie-background commentable non-processed" customid="Image_37"   datasizewidth="19.0px" datasizeheight="20.0px" dataX="420.0" dataY="327.0"   alt="image" systemName="./images/f40bc44f-2922-49e4-af2b-b9284890dda7.svg" overlay="#CBCBCB">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="20px" version="1.1" viewBox="0 0 19 20" width="19px">\
              	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
              	    <title>Icon</title>\
              	    <desc>Created with Sketch.</desc>\
              	    <defs />\
              	    <g fill="none" fill-rule="evenodd" id="s-Image_37-Page-1" stroke="none" stroke-width="1">\
              	        <g fill="#B1B1B1" id="Header-#6" transform="translate(-1068.000000, -25.000000)">\
              	            <g id="s-Image_37-Search-" transform="translate(1068.000000, 17.000000)">\
              	                <path d="M12.939,16.271 C12.939,19.121 10.621,21.439 7.771,21.439 C4.921,21.439 2.584,19.121 2.584,16.271 C2.584,13.402 4.902,11.084 7.771,11.084 C10.621,11.084 12.939,13.421 12.939,16.271 L12.939,16.271 Z M14.174,20.66 C15.067,19.387 15.542,17.829 15.542,16.271 C15.542,11.977 12.065,8.5 7.771,8.5 C3.477,8.5 0,11.977 0,16.271 C0,20.565 3.477,24.042 7.771,24.042 C9.329,24.042 10.887,23.548 12.179,22.674 L17.005,27.5 L19,25.505 L14.174,20.66 Z" id="s-Image_37-Icon" style="fill:#CBCBCB !important;" />\
              	            </g>\
              	        </g>\
              	    </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
\
        </div>\
\
\
        <div id="s-Group_5" class="group firer ie-background commentable non-processed" customid="Find Store" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Paragraph_1" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="135.2px" datasizeheight="38.0px" dataX="107.0" dataY="199.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_1_0">Find Store</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Group_3" class="group firer ie-background commentable non-processed" customid="Filter" datasizewidth="0.0px" datasizeheight="0.0px" >\
            <div id="s-Image_3" class="pie image lockV firer ie-background commentable non-processed" customid="Image 3"   datasizewidth="25.0px" datasizeheight="24.0px" dataX="367.0" dataY="246.0" aspectRatio="0.9609375"   alt="image">\
              <div class="borderLayer">\
              	<div class="imageViewport">\
              		<img src="./images/6fd951ec-7fd8-48ba-b21b-4de127b9d759.png" />\
              	</div>\
              </div>\
            </div>\
\
            <div id="s-Paragraph_3" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="67.4px" datasizeheight="22.0px" dataX="400.0" dataY="247.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Paragraph_3_0">FILTERS</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Paragraph_4" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="186.0px" datasizeheight="22.0px" dataX="107.0" dataY="247.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_4_0">Search by address, or zip</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
      </div>\
\
      <div id="s-Dynamic_Panel_1" class="pie dynamicpanel firer ie-background commentable non-processed" customid="Stores" datasizewidth="347.0px" datasizeheight="317.2px" dataX="107.0" dataY="400.0" >\
        <div id="s-Panel_1" class="pie panel default firer ie-background commentable non-processed" customid="Panel 1"  datasizewidth="347.0px" datasizeheight="317.2px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="layoutWrapper scrollable">\
          	  <div class="paddingLayer">\
                <div class="freeLayout">\
                <div id="s-Group_4" class="group firer ie-background commentable non-processed" customid="Store 3" datasizewidth="0.0px" datasizeheight="0.0px" >\
                  <div id="s-Paragraph_14" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="91.9px" datasizeheight="18.0px" dataX="20.0" dataY="310.0" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Paragraph_14_0">LOREM IPSUM</span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Paragraph_15" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="115.7px" datasizeheight="22.0px" dataX="20.0" dataY="270.0" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Paragraph_15_0">LOREM IPSUM</span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Rectangle_5" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle"   datasizewidth="347.0px" datasizeheight="120.8px" datasizewidthpx="347.0" datasizeheightpx="120.75000000000006" dataX="0.0" dataY="240.0" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Rectangle_5_0"></span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
\
\
                <div id="s-Group_2" class="group firer ie-background commentable non-processed" customid="Store 2" datasizewidth="0.0px" datasizeheight="0.0px" >\
                  <div id="s-Paragraph_11" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="91.9px" datasizeheight="18.0px" dataX="20.0" dataY="190.0" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Paragraph_11_0">LOREM IPSUM</span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Paragraph_5" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="115.7px" datasizeheight="22.0px" dataX="20.0" dataY="150.0" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Paragraph_5_0">LOREM IPSUM</span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Rectangle_1" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle"   datasizewidth="347.0px" datasizeheight="120.8px" datasizewidthpx="347.0" datasizeheightpx="120.75000000000006" dataX="0.0" dataY="120.0" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Rectangle_1_0"></span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
\
\
                <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Store 1" datasizewidth="0.0px" datasizeheight="0.0px" >\
                  <div id="s-Paragraph_12" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="91.9px" datasizeheight="18.0px" dataX="20.0" dataY="70.0" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Paragraph_12_0">LOREM IPSUM</span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Paragraph_13" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="115.7px" datasizeheight="22.0px" dataX="20.0" dataY="30.0" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Paragraph_13_0">LOREM IPSUM</span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Rectangle_4" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle"   datasizewidth="347.0px" datasizeheight="120.8px" datasizewidthpx="347.0" datasizeheightpx="120.75000000000006" dataX="0.0" dataY="0.0" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Rectangle_4_0"></span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
\
                </div>\
\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Dynamic_Panel_2" class="pie dynamicpanel firer ie-background commentable non-processed" customid="Dynamic Panel" datasizewidth="1173.0px" datasizeheight="159.0px" dataX="107.0" dataY="0.0" >\
        <div id="s-Panel_2" class="pie panel default firer ie-background commentable non-processed" customid="Panel 1"  datasizewidth="1173.0px" datasizeheight="159.0px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="layoutWrapper scrollable">\
          	  <div class="paddingLayer">\
                <div class="freeLayout">\
                <div id="s-Group_12" class="group firer ie-background commentable non-processed" customid="Logo" datasizewidth="0.0px" datasizeheight="0.0px" >\
                  <div id="s-Image_4" class="pie image firer ie-background commentable non-processed" customid="Image 2"   datasizewidth="150.0px" datasizeheight="150.0px" dataX="723.0" dataY="-1.0"   alt="image">\
                    <div class="borderLayer">\
                    	<div class="imageViewport">\
                    		<img src="./images/1e97dd1c-70b1-4229-a28f-3b7da1c7c18f.png" />\
                    	</div>\
                    </div>\
                  </div>\
\
                  <div id="s-Paragraph_16" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="114.8px" datasizeheight="45.0px" dataX="873.0" dataY="52.0" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Paragraph_16_0">NEDAP</span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
\
                <div id="s-Paragraph_2" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="394.8px" datasizeheight="110.0px" dataX="16.0" dataY="23.5" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Paragraph_2_0">Devision </span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                </div>\
\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;