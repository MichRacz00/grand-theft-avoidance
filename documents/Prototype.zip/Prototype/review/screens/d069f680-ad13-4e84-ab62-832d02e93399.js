var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1280" deviceHeight="800">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1619776791410.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1619776791410-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-d069f680-ad13-4e84-ab62-832d02e93399" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Manage Accounts" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/d069f680-ad13-4e84-ab62-832d02e93399-1619776791410.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/d069f680-ad13-4e84-ab62-832d02e93399-1619776791410-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/d069f680-ad13-4e84-ab62-832d02e93399-1619776791410-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Paragraph_2" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Title"   datasizewidth="485.0px" datasizeheight="90.0px" dataX="54.5" dataY="66.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0">Manage Accounts</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_1" class="pie button multiline manualfit firer ie-background commentable non-processed" customid="Button"   datasizewidth="135.0px" datasizeheight="32.0px" dataX="162.0" dataY="301.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">Add new account</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Table_1" class="pie table firer ie-background commentable non-processed" customid="Table"  datasizewidth="1016.0px" datasizeheight="296.0px" dataX="132.0" dataY="385.0" originalwidth="1015.9999999999993px" originalheight="296.0000000000001px" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <table summary="">\
              <tbody>\
                <tr>\
                  <td id="s-Cell_13" customid="Cell" class="pie cellcontainer firer ie-background non-processed"    datasizewidth="296.3px" datasizeheight="33.5px" dataX="0.0" dataY="0.0" originalwidth="296.33333333333303px" originalheight="33.50000000000003px" >\
                    <div class="cellContainerChild">\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                    	  <div class="layout scrollable">\
                    	    <div class="paddingLayer">\
                            <table class="layout" summary="">\
                              <tr>\
                                <td class="layout vertical insertionpoint verticalalign Cell_13 Table_1" valign="middle" align="center" hSpacing="0" vSpacing="0"></td> \
                              </tr>\
                            </table>\
\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </td>\
                  <td id="s-Cell_14" customid="Cell" class="pie cellcontainer firer ie-background non-processed"    datasizewidth="423.3px" datasizeheight="33.5px" dataX="0.0" dataY="0.0" originalwidth="423.33333333333303px" originalheight="33.50000000000003px" >\
                    <div class="cellContainerChild">\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                    	  <div class="layout scrollable">\
                    	    <div class="paddingLayer">\
                            <table class="layout" summary="">\
                              <tr>\
                                <td class="layout vertical insertionpoint verticalalign Cell_14 Table_1" valign="middle" align="center" hSpacing="0" vSpacing="0"></td> \
                              </tr>\
                            </table>\
\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </td>\
                  <td id="s-Cell_15" customid="Cell 5" class="pie cellcontainer firer ie-background non-processed"    datasizewidth="296.3px" datasizeheight="33.5px" dataX="0.0" dataY="0.0" originalwidth="296.33333333333303px" originalheight="33.50000000000003px" >\
                    <div class="cellContainerChild">\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                    	  <div class="layout scrollable">\
                    	    <div class="paddingLayer">\
                            <table class="layout" summary="">\
                              <tr>\
                                <td class="layout vertical insertionpoint verticalalign Cell_15 Table_1" valign="middle" align="center" hSpacing="0" vSpacing="0"></td> \
                              </tr>\
                            </table>\
\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </td>\
                </tr>\
                <tr>\
                  <td id="s-Cell_16" customid="Cell" class="pie cellcontainer firer ie-background non-processed"    datasizewidth="296.3px" datasizeheight="87.5px" dataX="0.0" dataY="0.0" originalwidth="296.33333333333303px" originalheight="87.50000000000003px" >\
                    <div class="cellContainerChild">\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                    	  <div class="layout scrollable">\
                    	    <div class="paddingLayer">\
                            <table class="layout" summary="">\
                              <tr>\
                                <td class="layout vertical insertionpoint verticalalign Cell_16 Table_1" valign="middle" align="center" hSpacing="0" vSpacing="0"></td> \
                              </tr>\
                            </table>\
\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </td>\
                  <td id="s-Cell_17" customid="Cell" class="pie cellcontainer firer ie-background non-processed"    datasizewidth="423.3px" datasizeheight="87.5px" dataX="0.0" dataY="0.0" originalwidth="423.33333333333303px" originalheight="87.50000000000003px" >\
                    <div class="cellContainerChild">\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                    	  <div class="layout scrollable">\
                    	    <div class="paddingLayer">\
                            <table class="layout" summary="">\
                              <tr>\
                                <td class="layout vertical insertionpoint verticalalign Cell_17 Table_1" valign="middle" align="center" hSpacing="0" vSpacing="0"></td> \
                              </tr>\
                            </table>\
\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </td>\
                  <td id="s-Cell_18" customid="Cell 6" class="pie cellcontainer firer ie-background non-processed"    datasizewidth="296.3px" datasizeheight="87.5px" dataX="0.0" dataY="0.0" originalwidth="296.33333333333303px" originalheight="87.50000000000003px" >\
                    <div class="cellContainerChild">\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                    	  <div class="layout scrollable">\
                    	    <div class="paddingLayer">\
                            <table class="layout" summary="">\
                              <tr>\
                                <td class="layout vertical insertionpoint verticalalign Cell_18 Table_1" valign="middle" align="center" hSpacing="0" vSpacing="0"></td> \
                              </tr>\
                            </table>\
\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </td>\
                </tr>\
                <tr>\
                  <td id="s-Cell_19" customid="Cell 7" class="pie cellcontainer firer ie-background non-processed"    datasizewidth="296.3px" datasizeheight="87.5px" dataX="0.0" dataY="0.0" originalwidth="296.33333333333303px" originalheight="87.50000000000003px" >\
                    <div class="cellContainerChild">\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                    	  <div class="layout scrollable">\
                    	    <div class="paddingLayer">\
                            <table class="layout" summary="">\
                              <tr>\
                                <td class="layout vertical insertionpoint verticalalign Cell_19 Table_1" valign="middle" align="center" hSpacing="0" vSpacing="0"></td> \
                              </tr>\
                            </table>\
\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </td>\
                  <td id="s-Cell_20" customid="Cell 8" class="pie cellcontainer firer ie-background non-processed"    datasizewidth="423.3px" datasizeheight="87.5px" dataX="0.0" dataY="0.0" originalwidth="423.33333333333303px" originalheight="87.50000000000003px" >\
                    <div class="cellContainerChild">\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                    	  <div class="layout scrollable">\
                    	    <div class="paddingLayer">\
                            <table class="layout" summary="">\
                              <tr>\
                                <td class="layout vertical insertionpoint verticalalign Cell_20 Table_1" valign="middle" align="center" hSpacing="0" vSpacing="0"></td> \
                              </tr>\
                            </table>\
\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </td>\
                  <td id="s-Cell_21" customid="Cell 9" class="pie cellcontainer firer ie-background non-processed"    datasizewidth="296.3px" datasizeheight="87.5px" dataX="0.0" dataY="0.0" originalwidth="296.33333333333303px" originalheight="87.50000000000003px" >\
                    <div class="cellContainerChild">\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                    	  <div class="layout scrollable">\
                    	    <div class="paddingLayer">\
                            <table class="layout" summary="">\
                              <tr>\
                                <td class="layout vertical insertionpoint verticalalign Cell_21 Table_1" valign="middle" align="center" hSpacing="0" vSpacing="0"></td> \
                              </tr>\
                            </table>\
\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </td>\
                </tr>\
                <tr>\
                  <td id="s-Cell_22" customid="Cell 10" class="pie cellcontainer firer ie-background non-processed"    datasizewidth="296.3px" datasizeheight="87.5px" dataX="0.0" dataY="0.0" originalwidth="296.33333333333303px" originalheight="87.50000000000003px" >\
                    <div class="cellContainerChild">\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                    	  <div class="layout scrollable">\
                    	    <div class="paddingLayer">\
                            <table class="layout" summary="">\
                              <tr>\
                                <td class="layout vertical insertionpoint verticalalign Cell_22 Table_1" valign="middle" align="center" hSpacing="0" vSpacing="0"></td> \
                              </tr>\
                            </table>\
\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </td>\
                  <td id="s-Cell_23" customid="Cell 11" class="pie cellcontainer firer ie-background non-processed"    datasizewidth="423.3px" datasizeheight="87.5px" dataX="0.0" dataY="0.0" originalwidth="423.33333333333303px" originalheight="87.50000000000003px" >\
                    <div class="cellContainerChild">\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                    	  <div class="layout scrollable">\
                    	    <div class="paddingLayer">\
                            <table class="layout" summary="">\
                              <tr>\
                                <td class="layout vertical insertionpoint verticalalign Cell_23 Table_1" valign="middle" align="center" hSpacing="0" vSpacing="0"></td> \
                              </tr>\
                            </table>\
\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </td>\
                  <td id="s-Cell_24" customid="Cell 12" class="pie cellcontainer firer ie-background non-processed"    datasizewidth="296.3px" datasizeheight="87.5px" dataX="0.0" dataY="0.0" originalwidth="296.33333333333303px" originalheight="87.50000000000003px" >\
                    <div class="cellContainerChild">\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                    	  <div class="layout scrollable">\
                    	    <div class="paddingLayer">\
                            <table class="layout" summary="">\
                              <tr>\
                                <td class="layout vertical insertionpoint verticalalign Cell_24 Table_1" valign="middle" align="center" hSpacing="0" vSpacing="0"></td> \
                              </tr>\
                            </table>\
\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </td>\
                </tr>\
              </tbody>\
            </table>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_1" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="35.6px" datasizeheight="15.0px" dataX="144.2" dataY="393.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Name</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_3" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="47.4px" datasizeheight="15.0px" dataX="438.5" dataY="393.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_3_0">Position</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_4" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="23.0px" datasizeheight="15.0px" dataX="865.0" dataY="393.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_4_0">Edit</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_2" class="pie button multiline manualfit firer click ie-background commentable non-processed" customid="Button"   datasizewidth="68.0px" datasizeheight="29.0px" dataX="978.0" dataY="444.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_2_0">Edit</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_3" class="pie button multiline manualfit firer click ie-background commentable non-processed" customid="Button"   datasizewidth="68.0px" datasizeheight="29.0px" dataX="1065.0" dataY="444.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_3_0">Remove</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_4" class="pie button multiline manualfit firer click ie-background commentable non-processed" customid="Button"   datasizewidth="68.0px" datasizeheight="29.0px" dataX="978.0" dataY="533.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_4_0">Edit</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_5" class="pie button multiline manualfit firer click ie-background commentable non-processed" customid="Button"   datasizewidth="68.0px" datasizeheight="29.0px" dataX="1065.0" dataY="533.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_5_0">Remove</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_5" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="49.7px" datasizeheight="15.0px" dataX="144.2" dataY="451.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_5_0">Joe Doe</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_6" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="79.3px" datasizeheight="15.0px" dataX="144.2" dataY="540.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_6_0">Janne Danne</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_7" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="88.2px" datasizeheight="15.0px" dataX="437.4" dataY="451.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_7_0">Store Manager</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_8" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="103.0px" datasizeheight="15.0px" dataX="437.4" dataY="540.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_8_0">Division Manager</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Category_2" class="pie dropdown firer commentable non-processed" customid="Category"    datasizewidth="214.0px" datasizeheight="32.0px" dataX="331.5" dataY="301.0"  tabindex="-1"><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content icon"><div class="valign"><div class="value">new value 1</div></div></div></div></div><select id="s-Category_2-options" class="s-d069f680-ad13-4e84-ab62-832d02e93399 dropdown-options" ><option selected="selected" class="option">new value 1</option>\
      <option  class="option">new value 2</option>\
      <option  class="option">new value 3</option></select></div>\
      <div id="s-Rectangle_3" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle"   datasizewidth="640.0px" datasizeheight="50.0px" datasizewidthpx="640.0000000000005" datasizeheightpx="50.0" dataX="640.0" dataY="188.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_3_0">Stores</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_4" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle"   datasizewidth="640.0px" datasizeheight="49.0px" datasizewidthpx="640.0000000000002" datasizeheightpx="49.000000000000114" dataX="0.0" dataY="189.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_4_0">Accounts</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Dynamic_Panel_4" class="pie dynamicpanel firer commentable hidden non-processed" customid="Dynamic Panel 2" datasizewidth="270.0px" datasizeheight="800.0px" dataX="0.0" dataY="-0.0" >\
        <div id="s-Panel_4" class="pie panel default firer commentable non-processed" customid="Panel 2"  datasizewidth="270.0px" datasizeheight="800.0px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="layoutWrapper scrollable">\
          	  <div class="paddingLayer">\
                <div class="freeLayout">\
                <div id="s-Rectangle_2" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle"   datasizewidth="270.0px" datasizeheight="87.4px" datasizewidthpx="270.0000000000003" datasizeheightpx="87.41666666666652" dataX="0.0" dataY="520.2" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Rectangle_2_0"></span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Rectangle_6" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle"   datasizewidth="270.0px" datasizeheight="87.4px" datasizewidthpx="269.9999999999999" datasizeheightpx="87.41666666666674" dataX="0.0" dataY="432.8" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Rectangle_6_0"></span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Rectangle_7" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle"   datasizewidth="270.0px" datasizeheight="87.4px" datasizewidthpx="269.9999999999999" datasizeheightpx="87.41666666666674" dataX="0.0" dataY="345.4" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Rectangle_7_0"></span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Rectangle_8" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle"   datasizewidth="270.0px" datasizeheight="87.4px" datasizewidthpx="269.9999999999999" datasizeheightpx="87.41666666666663" dataX="0.0" dataY="258.0" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Rectangle_8_0"></span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
\
                <div id="s-Image_2" class="pie image firer ie-background commentable non-processed" customid="Image"   datasizewidth="127.0px" datasizeheight="125.0px" dataX="71.5" dataY="86.0"   alt="image">\
                  <div class="borderLayer">\
                  	<div class="imageViewport">\
                  		<img src="resources/jim/images/common/cross.svg" />\
                  	</div>\
                  </div>\
                </div>\
\
                <div id="s-Paragraph_9" class="pie richtext autofit firer click ie-background commentable non-processed" customid="Paragraph"   datasizewidth="156.5px" datasizeheight="36.0px" dataX="14.5" dataY="283.7" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Paragraph_9_0">Dashboard</span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Paragraph_10" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="161.8px" datasizeheight="36.0px" dataX="10.0" dataY="370.0" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Paragraph_10_0">Time - theft</span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Paragraph_11" class="pie richtext autofit firer click ie-background commentable non-processed" customid="Paragraph"   datasizewidth="186.8px" datasizeheight="36.0px" dataX="10.0" dataY="460.0" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Paragraph_11_0">Management</span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Paragraph_12" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="158.3px" datasizeheight="36.0px" dataX="10.0" dataY="545.0" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Paragraph_12_0">Predictions</span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Rectangle_5" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle"   datasizewidth="270.0px" datasizeheight="87.4px" datasizewidthpx="270.0000000000003" datasizeheightpx="87.41666666666652" dataX="0.0" dataY="607.7" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Rectangle_5_0"></span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Paragraph_13" class="pie richtext autofit firer click ie-background commentable non-processed" customid="Paragraph"   datasizewidth="97.9px" datasizeheight="36.0px" dataX="10.0" dataY="633.4" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Paragraph_13_0">Logout</span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                </div>\
\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_22" class="pie image firer click ie-background commentable non-processed" customid="Image_22"   datasizewidth="39.0px" datasizeheight="23.0px" dataX="26.0" dataY="27.0"   alt="image" systemName="./images/058c3b47-d114-435d-8922-819c93f5c17c.svg" overlay="#434343">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="18px" version="1.1" viewBox="0 0 25 18" width="25px">\
          	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
          	    <title>Menu Burger Icon</title>\
          	    <desc>Created with Sketch.</desc>\
          	    <defs />\
          	    <g fill="none" fill-rule="evenodd" id="s-Image_22-Page-1" stroke="none" stroke-width="1">\
          	        <g fill="#333333" id="Header-#2" transform="translate(-120.000000, -26.000000)">\
          	            <g id="s-Image_22-Top">\
          	                <path d="M145,26 L145,28 L120,28 L120,26 L145,26 Z M145,42 L145,44 L120,44 L120,42 L145,42 Z M145,34 L145,36 L120,36 L120,34 L145,34 Z" id="s-Image_22-Menu-Burger-Icon" style="fill:#434343 !important;" />\
          	            </g>\
          	        </g>\
          	    </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;