var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1280" deviceHeight="800">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1619776791410.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1619776791410-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-d12245cc-1680-458d-89dd-4f0d7fb22724" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Login" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/d12245cc-1680-458d-89dd-4f0d7fb22724-1619776791410.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/d12245cc-1680-458d-89dd-4f0d7fb22724-1619776791410-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/d12245cc-1680-458d-89dd-4f0d7fb22724-1619776791410-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Group_4" class="group firer ie-background commentable non-processed" customid="Background" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Group_2" class="group firer ie-background commentable non-processed" customid="Lower" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="shapewrapper-s-Ellipse_3" customid="Ellipse 3" class="shapewrapper shapewrapper-s-Ellipse_3 non-processed"  rotationdeg="36" datasizewidth="518.0px" datasizeheight="397.0px" datasizewidthpx="518.0000000000002" datasizeheightpx="397.0000000000001" dataX="-128.0" dataY="671.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_3" class="svgContainer" style="width:100%; height:100%;">\
                  <g>\
                      <g clip-path="url(#clip-s-Ellipse_3)">\
                              <ellipse id="s-Ellipse_3" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse 3" cx="259.0000000000001" cy="198.50000000000006" rx="259.0000000000001" ry="198.50000000000006">\
                              </ellipse>\
                      </g>\
                  </g>\
                  <defs>\
                      <clipPath id="clip-s-Ellipse_3" class="clipPath">\
                              <ellipse cx="259.0000000000001" cy="198.50000000000006" rx="259.0000000000001" ry="198.50000000000006">\
                              </ellipse>\
                      </clipPath>\
                  </defs>\
              </svg>\
              <div class="paddingLayer">\
                  <div id="shapert-s-Ellipse_3" class="content firer" >\
                      <div class="valign">\
                          <span id="rtr-s-Ellipse_3_0"></span>\
                      </div>\
                  </div>\
              </div>\
          </div>\
          <div id="shapewrapper-s-Ellipse_4" customid="Ellipse 4" class="shapewrapper shapewrapper-s-Ellipse_4 non-processed"   datasizewidth="245.0px" datasizeheight="206.0px" datasizewidthpx="245.0" datasizeheightpx="206.0" dataX="169.0" dataY="744.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_4" class="svgContainer" style="width:100%; height:100%;">\
                  <g>\
                      <g clip-path="url(#clip-s-Ellipse_4)">\
                              <ellipse id="s-Ellipse_4" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse 4" cx="122.5" cy="103.0" rx="122.5" ry="103.0">\
                              </ellipse>\
                      </g>\
                  </g>\
                  <defs>\
                      <clipPath id="clip-s-Ellipse_4" class="clipPath">\
                              <ellipse cx="122.5" cy="103.0" rx="122.5" ry="103.0">\
                              </ellipse>\
                      </clipPath>\
                  </defs>\
              </svg>\
              <div class="paddingLayer">\
                  <div id="shapert-s-Ellipse_4" class="content firer" >\
                      <div class="valign">\
                          <span id="rtr-s-Ellipse_4_0"></span>\
                      </div>\
                  </div>\
              </div>\
          </div>\
        </div>\
\
\
        <div id="s-Group_3" class="group firer ie-background commentable non-processed" customid="Up" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="shapewrapper-s-Ellipse_1" customid="Ellipse 1" class="shapewrapper shapewrapper-s-Ellipse_1 non-processed"   datasizewidth="441.0px" datasizeheight="357.0px" datasizewidthpx="440.9999999999998" datasizeheightpx="356.99999999999994" dataX="998.0" dataY="-62.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_1" class="svgContainer" style="width:100%; height:100%;">\
                  <g>\
                      <g clip-path="url(#clip-s-Ellipse_1)">\
                              <ellipse id="s-Ellipse_1" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse 1" cx="220.4999999999999" cy="178.49999999999997" rx="220.4999999999999" ry="178.49999999999997">\
                              </ellipse>\
                      </g>\
                  </g>\
                  <defs>\
                      <clipPath id="clip-s-Ellipse_1" class="clipPath">\
                              <ellipse cx="220.4999999999999" cy="178.49999999999997" rx="220.4999999999999" ry="178.49999999999997">\
                              </ellipse>\
                      </clipPath>\
                  </defs>\
              </svg>\
              <div class="paddingLayer">\
                  <div id="shapert-s-Ellipse_1" class="content firer" >\
                      <div class="valign">\
                          <span id="rtr-s-Ellipse_1_0"></span>\
                      </div>\
                  </div>\
              </div>\
          </div>\
          <div id="shapewrapper-s-Ellipse_2" customid="Ellipse 2" class="shapewrapper shapewrapper-s-Ellipse_2 non-processed"   datasizewidth="30.0px" datasizeheight="30.0px" datasizewidthpx="30.0" datasizeheightpx="30.0" dataX="998.0" dataY="30.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_2" class="svgContainer" style="width:100%; height:100%;">\
                  <g>\
                      <g clip-path="url(#clip-s-Ellipse_2)">\
                              <ellipse id="s-Ellipse_2" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse 2" cx="15.0" cy="15.0" rx="15.0" ry="15.0">\
                              </ellipse>\
                      </g>\
                  </g>\
                  <defs>\
                      <clipPath id="clip-s-Ellipse_2" class="clipPath">\
                              <ellipse cx="15.0" cy="15.0" rx="15.0" ry="15.0">\
                              </ellipse>\
                      </clipPath>\
                  </defs>\
              </svg>\
              <div class="paddingLayer">\
                  <div id="shapert-s-Ellipse_2" class="content firer" >\
                      <div class="valign">\
                          <span id="rtr-s-Ellipse_2_0"></span>\
                      </div>\
                  </div>\
              </div>\
          </div>\
          <div id="shapewrapper-s-Ellipse_5" customid="Ellipse 2" class="shapewrapper shapewrapper-s-Ellipse_5 non-processed"   datasizewidth="15.0px" datasizeheight="15.0px" datasizewidthpx="15.0" datasizeheightpx="15.0" dataX="955.0" dataY="19.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_5" class="svgContainer" style="width:100%; height:100%;">\
                  <g>\
                      <g clip-path="url(#clip-s-Ellipse_5)">\
                              <ellipse id="s-Ellipse_5" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse 2" cx="7.5" cy="7.5" rx="7.5" ry="7.5">\
                              </ellipse>\
                      </g>\
                  </g>\
                  <defs>\
                      <clipPath id="clip-s-Ellipse_5" class="clipPath">\
                              <ellipse cx="7.5" cy="7.5" rx="7.5" ry="7.5">\
                              </ellipse>\
                      </clipPath>\
                  </defs>\
              </svg>\
              <div class="paddingLayer">\
                  <div id="shapert-s-Ellipse_5" class="content firer" >\
                      <div class="valign">\
                          <span id="rtr-s-Ellipse_5_0"></span>\
                      </div>\
                  </div>\
              </div>\
          </div>\
        </div>\
\
      </div>\
\
\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Log in" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Group_5" class="group firer ie-background commentable non-processed" customid="Log in Title" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Paragraph_2" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph 2"   datasizewidth="160.1px" datasizeheight="75.0px" dataX="565.0" dataY="185.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_2_0">Login</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="shapewrapper-s-Line_1" customid="Line 1" class="shapewrapper shapewrapper-s-Line_1 non-processed"   datasizewidth="200.8px" datasizeheight="5.0px" datasizewidthpx="200.83637307076714" datasizeheightpx="5.0" dataX="541.0" dataY="264.0" >\
              <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_1" class="svgContainer" style="width:100%;height:100%;">\
                  <g>\
                      <g>\
                          <path id="s-Line_1" class="pie line shape non-processed-shape firer ie-background commentable non-processed" customid="Line 1" d="M 0.0 2.5 L 200.83637307076714 2.5"  >\
                          </path>\
                      </g>\
                  </g>\
                  <defs>\
                  </defs>\
              </svg>\
          </div>\
        </div>\
\
\
        <div id="s-Group_6" class="group firer ie-background commentable non-processed" customid="Inboxes" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Input_1" class="pie text firer commentable non-processed" customid="Input"  datasizewidth="401.0px" datasizeheight="48.0px" dataX="440.0" dataY="401.0" ><div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Username"/></div></div>  </div></div></div>\
          <div id="s-Input_2" class="pie password firer commentable non-processed" customid="Input"  datasizewidth="401.0px" datasizeheight="48.0px" dataX="440.0" dataY="461.0" ><div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="password"  value="" maxlength="100"  tabindex="-1" placeholder="Password"/></div></div></div></div></div>\
        </div>\
\
        <div id="s-Paragraph_1" class="pie richtext autofit firer ie-background commentable non-processed" customid="Description"   datasizewidth="297.9px" datasizeheight="36.0px" dataX="492.0" dataY="307.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_1_0">Welcome , please Login to access GTA 6.<br />Did you</span><span id="rtr-s-Paragraph_1_1"> </span><span id="rtr-s-Paragraph_1_2">forget your password ?</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Group_7" class="group firer ie-background commentable non-processed" customid="Remember me" datasizewidth="0.0px" datasizeheight="0.0px" >\
            <div id="s-Input_3" class="pie checkbox firer commentable non-processed nonMobile" customid="Input" datasizewidth="15.0px" datasizeheight="15.0px" dataX="443.0" dataY="543.0" >\
              <input class="checkBoxInput" type="checkbox"      tabindex="-1" >\
            </div>\
\
          <div id="s-Paragraph_3" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="92.5px" datasizeheight="18.0px" dataX="472.0" dataY="540.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_3_0">Remeber me</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
\
        <div id="s-Group_8" class="group firer ie-background commentable non-processed" customid="Continue Button" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Button_1" class="pie button multiline manualfit firer click commentable non-processed" customid="Button"   datasizewidth="381.0px" datasizeheight="49.0px" dataX="447.0" dataY="597.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Button_1_0">Button</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_4" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="94.7px" datasizeheight="30.0px" dataX="575.0" dataY="608.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_4_0">Continue</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Image_5" class="pie image firer ie-background commentable non-processed" customid="Image_5"   datasizewidth="15.0px" datasizeheight="20.0px" dataX="682.0" dataY="614.0"   alt="image" systemName="./images/3a136aaf-3f80-4954-9c60-403158e9dca8.svg" overlay="#FFFFFF">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="27px" version="1.1" viewBox="0 0 15 27" width="15px">\
              	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
              	    <title>Arrow Right</title>\
              	    <desc>Created with Sketch.</desc>\
              	    <defs />\
              	    <g fill="none" fill-rule="evenodd" id="s-Image_5-Page-1" stroke="none" stroke-width="1">\
              	        <g fill="#DDDDDD" id="s-Image_5-Components" transform="translate(-463.000000, -1276.000000)">\
              	            <g id="s-Image_5-Arrow-Right" transform="translate(463.000000, 1276.000000)">\
              	                <polyline points="1.157 0 0 1.144 12.325 13.62 0 25.691 1.325 27 15 13.691 1.157 0" style="fill:#FFFFFF !important;" />\
              	            </g>\
              	        </g>\
              	    </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
\
        </div>\
\
      </div>\
\
\
      <div id="s-Group_9" class="group firer ie-background commentable non-processed" customid="Logo" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Image_2" class="pie image firer ie-background commentable non-processed" customid="Image 2"   datasizewidth="150.0px" datasizeheight="150.0px" dataX="13.0" dataY="0.0"   alt="image">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
          		<img src="./images/1e97dd1c-70b1-4229-a28f-3b7da1c7c18f.png" />\
          	</div>\
          </div>\
        </div>\
\
        <div id="s-Paragraph_5" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="114.8px" datasizeheight="45.0px" dataX="163.0" dataY="52.5" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_5_0">NEDAP</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;