var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1280" deviceHeight="800">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1619776791410.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1619776791410-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1619776791410-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-f72c652b-60de-4114-bfaf-5451b9bca421" class="screen growth-vertical devWeb canvas PORTRAIT firer commentable non-processed" alignment="left" name="Manage Stores" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/f72c652b-60de-4114-bfaf-5451b9bca421-1619776791410.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/f72c652b-60de-4114-bfaf-5451b9bca421-1619776791410-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/f72c652b-60de-4114-bfaf-5451b9bca421-1619776791410-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Search-input" class="group firer ie-background commentable non-processed" customid="Search-input" datasizewidth="347.0px" datasizeheight="46.0px" >\
        <div id="s-Input_search" class="pie text firer commentable non-processed" customid="Input_search"  datasizewidth="347.0px" datasizeheight="46.0px" dataX="90.0" dataY="297.0" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Search for store"/></div></div>  </div></div></div>\
\
        <div id="s-Image_37" class="pie image firer ie-background commentable non-processed" customid="Image_37"   datasizewidth="19.0px" datasizeheight="20.0px" dataX="403.0" dataY="309.0"   alt="image" systemName="./images/4e39b31f-127c-4140-b264-29d14dffbd93.svg" overlay="#CBCBCB">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="20px" version="1.1" viewBox="0 0 19 20" width="19px">\
            	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
            	    <title>Icon</title>\
            	    <desc>Created with Sketch.</desc>\
            	    <defs />\
            	    <g fill="none" fill-rule="evenodd" id="s-Image_37-Page-1" stroke="none" stroke-width="1">\
            	        <g fill="#B1B1B1" id="Header-#6" transform="translate(-1068.000000, -25.000000)">\
            	            <g id="s-Image_37-Search-" transform="translate(1068.000000, 17.000000)">\
            	                <path d="M12.939,16.271 C12.939,19.121 10.621,21.439 7.771,21.439 C4.921,21.439 2.584,19.121 2.584,16.271 C2.584,13.402 4.902,11.084 7.771,11.084 C10.621,11.084 12.939,13.421 12.939,16.271 L12.939,16.271 Z M14.174,20.66 C15.067,19.387 15.542,17.829 15.542,16.271 C15.542,11.977 12.065,8.5 7.771,8.5 C3.477,8.5 0,11.977 0,16.271 C0,20.565 3.477,24.042 7.771,24.042 C9.329,24.042 10.887,23.548 12.179,22.674 L17.005,27.5 L19,25.505 L14.174,20.66 Z" id="s-Image_37-Icon" style="fill:#CBCBCB !important;" />\
            	            </g>\
            	        </g>\
            	    </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
\
      </div>\
\
      <div id="s-Rectangle_1" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle"   datasizewidth="1280.0px" datasizeheight="189.0px" datasizewidthpx="1280.0000000000007" datasizeheightpx="189.0" dataX="-0.0" dataY="-0.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_1" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="325.5px" datasizeheight="55.0px" dataX="75.0" dataY="67.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Manage Stores</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_3" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle"   datasizewidth="640.0px" datasizeheight="50.0px" datasizewidthpx="640.0000000000005" datasizeheightpx="50.0" dataX="0.0" dataY="189.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_3_0">Accounts</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_4" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle"   datasizewidth="640.0px" datasizeheight="49.0px" datasizewidthpx="640.0000000000002" datasizeheightpx="49.000000000000114" dataX="640.0" dataY="189.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_4_0">Stores</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Table_1" class="pie table firer commentable non-processed" customid="Table"  datasizewidth="1077.4px" datasizeheight="258.3px" dataX="90.0" dataY="412.0" originalwidth="1075.3532868397256px" originalheight="256.33333333333337px" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <table summary="">\
              <tbody>\
                <tr>\
                  <td id="s-Text_cell_17" class="pie textcell manualfit firer ie-background non-processed" customid="Text cell 13"     datasizewidth="180.4px" datasizeheight="43.3px" dataX="0.0" dataY="33.3" originalwidth="179.37661916855032px" originalheight="42.33333333333335px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_17_0">Name</span></div></div></div></div></div></div>  </td>\
                  <td id="s-Text_cell_18" class="pie textcell manualfit firer ie-background non-processed" customid="Text cell 14"     datasizewidth="434.2px" datasizeheight="43.3px" dataX="0.0" dataY="33.3" originalwidth="433.20044207477645px" originalheight="42.33333333333335px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_18_0">Address</span></div></div></div></div></div></div>  </td>\
                  <td id="s-Text_cell_19" class="pie textcell manualfit firer ie-background non-processed" customid="Text cell 15"     datasizewidth="291.3px" datasizeheight="43.3px" dataX="0.0" dataY="33.3" originalwidth="290.3332980819522px" originalheight="42.33333333333335px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_19_0">Division Manager</span></div></div></div></div></div></div>  </td>\
                  <td id="s-Text_cell_20" class="pie textcell manualfit firer ie-background non-processed" customid="Text cell 16"     datasizewidth="173.4px" datasizeheight="43.3px" dataX="0.0" dataY="33.3" originalwidth="172.44292751444684px" originalheight="42.33333333333335px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_20_0">Edit</span></div></div></div></div></div></div>  </td>\
                </tr>\
                <tr>\
                  <td id="s-Text_cell_21" class="pie textcell manualfit firer ie-background non-processed" customid="Text cell"     datasizewidth="180.4px" datasizeheight="72.3px" dataX="0.0" dataY="33.3" originalwidth="179.37661916855032px" originalheight="71.33333333333334px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_21_0">Store 1</span></div></div></div></div></div></div>  </td>\
                  <td id="s-Text_cell_22" class="pie textcell manualfit firer ie-background non-processed" customid="Text cell"     datasizewidth="434.2px" datasizeheight="72.3px" dataX="0.0" dataY="33.3" originalwidth="433.20044207477645px" originalheight="71.33333333333334px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_22_0">Adress 1</span></div></div></div></div></div></div>  </td>\
                  <td id="s-Text_cell_23" class="pie textcell manualfit firer ie-background non-processed" customid="Text cell 7"     datasizewidth="291.3px" datasizeheight="72.3px" dataX="0.0" dataY="33.3" originalwidth="290.3332980819522px" originalheight="71.33333333333334px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_23_0">Division Manager</span></div></div></div></div></div></div>  </td>\
                  <td id="s-Text_cell_24" class="pie textcell manualfit firer ie-background non-processed" customid="Text cell 10"     datasizewidth="173.4px" datasizeheight="72.3px" dataX="0.0" dataY="33.3" originalwidth="172.44292751444684px" originalheight="71.33333333333334px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_24_0"></span></div></div></div></div></div></div>  </td>\
                </tr>\
                <tr>\
                  <td id="s-Text_cell_25" class="pie textcell manualfit firer ie-background non-processed" customid="Text cell"     datasizewidth="180.4px" datasizeheight="72.3px" dataX="0.0" dataY="33.3" originalwidth="179.37661916855032px" originalheight="71.33333333333334px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_25_0">Store 2</span></div></div></div></div></div></div>  </td>\
                  <td id="s-Text_cell_26" class="pie textcell manualfit firer ie-background non-processed" customid="Text cell"     datasizewidth="434.2px" datasizeheight="72.3px" dataX="0.0" dataY="33.3" originalwidth="433.20044207477645px" originalheight="71.33333333333334px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_26_0">Address 2</span></div></div></div></div></div></div>  </td>\
                  <td id="s-Text_cell_27" class="pie textcell manualfit firer ie-background non-processed" customid="Text cell 8"     datasizewidth="291.3px" datasizeheight="72.3px" dataX="0.0" dataY="33.3" originalwidth="290.3332980819522px" originalheight="71.33333333333334px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_27_0">Division Manager</span></div></div></div></div></div></div>  </td>\
                  <td id="s-Text_cell_28" class="pie textcell manualfit firer ie-background non-processed" customid="Text cell 11"     datasizewidth="173.4px" datasizeheight="72.3px" dataX="0.0" dataY="33.3" originalwidth="172.44292751444684px" originalheight="71.33333333333334px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_28_0"></span></div></div></div></div></div></div>  </td>\
                </tr>\
                <tr>\
                  <td id="s-Text_cell_29" class="pie textcell manualfit firer ie-background non-processed" customid="Text cell"     datasizewidth="180.4px" datasizeheight="72.3px" dataX="0.0" dataY="33.3" originalwidth="179.37661916855032px" originalheight="71.33333333333334px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_29_0">Store 3</span></div></div></div></div></div></div>  </td>\
                  <td id="s-Text_cell_30" class="pie textcell manualfit firer ie-background non-processed" customid="Text cell"     datasizewidth="434.2px" datasizeheight="72.3px" dataX="0.0" dataY="33.3" originalwidth="433.20044207477645px" originalheight="71.33333333333334px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_30_0">Adress 3</span></div></div></div></div></div></div>  </td>\
                  <td id="s-Text_cell_31" class="pie textcell manualfit firer ie-background non-processed" customid="Text cell 9"     datasizewidth="291.3px" datasizeheight="72.3px" dataX="0.0" dataY="33.3" originalwidth="290.3332980819522px" originalheight="71.33333333333334px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_31_0">Division Manager</span></div></div></div></div></div></div>  </td>\
                  <td id="s-Text_cell_32" class="pie textcell manualfit firer ie-background non-processed" customid="Text cell 12"     datasizewidth="173.4px" datasizeheight="72.3px" dataX="0.0" dataY="33.3" originalwidth="172.44292751444684px" originalheight="71.33333333333334px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_32_0"></span></div></div></div></div></div></div>  </td>\
                </tr>\
              </tbody>\
            </table>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_1" class="pie button multiline manualfit firer ie-background commentable non-processed" customid="Button"   datasizewidth="68.0px" datasizeheight="29.0px" dataX="1003.0" dataY="615.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">Edit</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_2" class="pie button multiline manualfit firer ie-background commentable non-processed" customid="Button"   datasizewidth="68.0px" datasizeheight="29.0px" dataX="1003.0" dataY="468.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_2_0">Edit</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_3" class="pie button multiline manualfit firer ie-background commentable non-processed" customid="Button"   datasizewidth="68.0px" datasizeheight="29.0px" dataX="1003.0" dataY="541.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_3_0">Edit</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_4" class="pie button multiline manualfit firer ie-background commentable non-processed" customid="Button"   datasizewidth="68.0px" datasizeheight="29.0px" dataX="1084.0" dataY="615.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_4_0">Remove</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_5" class="pie button multiline manualfit firer ie-background commentable non-processed" customid="Button"   datasizewidth="68.0px" datasizeheight="29.0px" dataX="1084.0" dataY="469.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_5_0">Remove</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_6" class="pie button multiline manualfit firer ie-background commentable non-processed" customid="Button"   datasizewidth="68.0px" datasizeheight="29.0px" dataX="1084.0" dataY="541.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_6_0">Remove</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_2" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle"   datasizewidth="161.0px" datasizeheight="53.0px" datasizewidthpx="161.0" datasizeheightpx="53.0" dataX="1006.0" dataY="293.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_2_0">Add Store +</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Dynamic_Panel_4" class="pie dynamicpanel firer commentable hidden non-processed" customid="Dynamic Panel 2" datasizewidth="270.0px" datasizeheight="800.0px" dataX="0.0" dataY="0.0" >\
        <div id="s-Panel_4" class="pie panel default firer commentable non-processed" customid="Panel 2"  datasizewidth="270.0px" datasizeheight="800.0px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="layoutWrapper scrollable">\
          	  <div class="paddingLayer">\
                <div class="freeLayout">\
                <div id="s-Rectangle_5" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle"   datasizewidth="270.0px" datasizeheight="87.4px" datasizewidthpx="270.0000000000003" datasizeheightpx="87.41666666666652" dataX="0.0" dataY="520.2" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Rectangle_5_0"></span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Rectangle_6" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle"   datasizewidth="270.0px" datasizeheight="87.4px" datasizewidthpx="269.9999999999999" datasizeheightpx="87.41666666666674" dataX="0.0" dataY="432.8" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Rectangle_6_0"></span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Rectangle_7" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle"   datasizewidth="270.0px" datasizeheight="87.4px" datasizewidthpx="269.9999999999999" datasizeheightpx="87.41666666666674" dataX="0.0" dataY="345.4" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Rectangle_7_0"></span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Rectangle_8" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle"   datasizewidth="270.0px" datasizeheight="87.4px" datasizewidthpx="269.9999999999999" datasizeheightpx="87.41666666666663" dataX="0.0" dataY="258.0" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Rectangle_8_0"></span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
\
                <div id="s-Image_2" class="pie image firer ie-background commentable non-processed" customid="Image"   datasizewidth="127.0px" datasizeheight="125.0px" dataX="71.5" dataY="86.0"   alt="image">\
                  <div class="borderLayer">\
                  	<div class="imageViewport">\
                  		<img src="resources/jim/images/common/cross.svg" />\
                  	</div>\
                  </div>\
                </div>\
\
                <div id="s-Paragraph_6" class="pie richtext autofit firer click ie-background commentable non-processed" customid="Paragraph"   datasizewidth="156.5px" datasizeheight="36.0px" dataX="14.5" dataY="283.7" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Paragraph_6_0">Dashboard</span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Paragraph_7" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="161.8px" datasizeheight="36.0px" dataX="10.0" dataY="370.0" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Paragraph_7_0">Time - theft</span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Paragraph_8" class="pie richtext autofit firer click ie-background commentable non-processed" customid="Paragraph"   datasizewidth="186.8px" datasizeheight="36.0px" dataX="10.0" dataY="460.0" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Paragraph_8_0">Management</span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Paragraph_9" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="158.3px" datasizeheight="36.0px" dataX="10.0" dataY="545.0" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Paragraph_9_0">Predictions</span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Rectangle_9" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle"   datasizewidth="270.0px" datasizeheight="87.4px" datasizewidthpx="270.0000000000003" datasizeheightpx="87.41666666666652" dataX="0.0" dataY="607.7" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Rectangle_9_0"></span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Paragraph_10" class="pie richtext autofit firer click ie-background commentable non-processed" customid="Paragraph"   datasizewidth="97.9px" datasizeheight="36.0px" dataX="10.0" dataY="633.4" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Paragraph_10_0">Logout</span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                </div>\
\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_22" class="pie image firer click doubleclick ie-background commentable non-processed" customid="Image_22"   datasizewidth="39.0px" datasizeheight="23.0px" dataX="31.0" dataY="22.0"   alt="image" systemName="./images/f35a0bff-ed96-4a28-a5a7-08a648bced8e.svg" overlay="#434343">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="18px" version="1.1" viewBox="0 0 25 18" width="25px">\
          	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
          	    <title>Menu Burger Icon</title>\
          	    <desc>Created with Sketch.</desc>\
          	    <defs />\
          	    <g fill="none" fill-rule="evenodd" id="s-Image_22-Page-1" stroke="none" stroke-width="1">\
          	        <g fill="#333333" id="Header-#2" transform="translate(-120.000000, -26.000000)">\
          	            <g id="s-Image_22-Top">\
          	                <path d="M145,26 L145,28 L120,28 L120,26 L145,26 Z M145,42 L145,44 L120,44 L120,42 L145,42 Z M145,34 L145,36 L120,36 L120,34 L145,34 Z" id="s-Image_22-Menu-Burger-Icon" style="fill:#434343 !important;" />\
          	            </g>\
          	        </g>\
          	    </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_9" class="group firer ie-background commentable non-processed" customid="Logo" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Image_3" class="pie image firer ie-background commentable non-processed" customid="Image 2"   datasizewidth="150.0px" datasizeheight="150.0px" dataX="986.0" dataY="19.0"   alt="image">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
          		<img src="./images/1e97dd1c-70b1-4229-a28f-3b7da1c7c18f.png" />\
          	</div>\
          </div>\
        </div>\
\
        <div id="s-Paragraph_5" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="114.8px" datasizeheight="45.0px" dataX="1136.0" dataY="72.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_5_0">NEDAP</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;